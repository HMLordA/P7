function y=ur(t)
  y=0;

